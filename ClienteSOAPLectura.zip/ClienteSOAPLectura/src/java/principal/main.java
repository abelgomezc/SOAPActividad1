/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package principal;

import com.formdev.flatlaf.intellijthemes.FlatArcOrangeIJTheme;
import com.formdev.flatlaf.intellijthemes.materialthemeuilite.FlatNightOwlIJTheme;
import modelo.TestWS;
import vista.Login;
import vista.Registro;
import vista.vistaCuenta;

/**
 *
 * @author Abel Gomez
 */
public class main {

    public static void main(String[] args) {
        FlatArcOrangeIJTheme.setup();
        Registro vistaRegistro = new Registro();
        Login vistaLogin = new Login();
        vistaCuenta vistaCuenta = new vistaCuenta();
        TestWS test = new TestWS(vistaRegistro, vistaLogin, vistaCuenta);

        test.iniciarcontrol();

    }

}
