/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import cs.CuentasServicio;
import cs.CuentasServicio_Service;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;
import javax.swing.Timer;
import vista.Login;
import vista.Registro;
import vista.vistaCuenta;

/**
 *
 * @author Abel Gomez
 */
public class TestWS {

    private Registro vistaregistro;
    private Login vistaLogin;
    private vistaCuenta vistacuenta;

    CuentasServicio_Service servicio = new CuentasServicio_Service();
    CuentasServicio cliente = servicio.getCuentasServicioPort();

    public TestWS(Registro vistaregistro, Login vistaLogin, vistaCuenta vistacuenta) {
        this.vistaregistro = vistaregistro;
        this.vistaLogin = vistaLogin;
        this.vistacuenta = vistacuenta;
        vistaLogin.setVisible(true);
    }

    public void iniciarcontrol() {
        vistaregistro.getBtnregistar().addActionListener(l -> registar());
        vistaLogin.getBtnregistarse().addActionListener(l -> abrirregistro());

        vistaLogin.getBtningresar().addActionListener(l -> iniciarSesion());
        vistaregistro.getBtnatarsregistro().addActionListener(l -> atrasRegistro());
        vistacuenta.getBtnregistar().addActionListener(l -> actualizarSaldo());

        vistacuenta.getBtncerrarsesion().addActionListener(l -> cerrarSesion());

        vistaregistro.getTxtsaldo().addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                String value = vistaregistro.getTxtsaldo().getText();
                int pointCount = value.length() - value.replace(".", "").length();
                if (!((c >= '0') && (c <= '9') || (c == '.' && (pointCount == 0 || pointCount == 1))
                        || (c == KeyEvent.VK_BACK_SPACE)
                        || (c == KeyEvent.VK_DELETE))) {
                    e.consume();
                }
            }
        });

        vistacuenta.getTxtvalor().addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                String value = vistaregistro.getTxtsaldo().getText();
                int pointCount = value.length() - value.replace(".", "").length();
                if (!((c >= '0') && (c <= '9') || (c == '.' && (pointCount == 0 || pointCount == 1))
                        || (c == KeyEvent.VK_BACK_SPACE)
                        || (c == KeyEvent.VK_DELETE))) {
                    e.consume();
                }
            }
        });

        //  add(vistaregistro.getTxtsaldo());
    }

    public void registar() {
        if (validarCamposRegistro() == true) {
            Boolean registro = cliente.crearCuenta(vistaregistro.getTxtusuario().getText(), vistaregistro.getTxtclave().getText(), vistaregistro.getTxtclaveconfirmacion().getText(), Double.parseDouble(vistaregistro.getTxtsaldo().getText()));
            if (registro) {
                vistaregistro.getLbmensaje().setText("Usuario Registrado con èxito.");
                vistaregistro.getLbmensaje().setForeground(Color.BLUE);

                // temporizador que cambia de JFrame 
                Timer timer = new Timer(3000, e -> {
                    vistaLogin.setVisible(true);
                    vistaregistro.setVisible(false);
                    limpiarDatosRegistro();
                    limpiarDatosLogin();
                });
                timer.setRepeats(false);  // Solo se ejecuta una vez
                timer.start();

            } else {

                vistaregistro.getLbmensaje().setText("Error en el Registro.");
                vistaregistro.getLbmensaje().setForeground(Color.red);
            }

        } else {

            vistaregistro.getLbmensaje().setText("Campos Vacios.");
            vistaregistro.getLbmensaje().setForeground(Color.red);
        }

    }

    public void abrirregistro() {
        vistaLogin.setVisible(false);
        vistaregistro.setVisible(true);
    }

    public void iniciarSesion() {

        if (validarCamposLogin() == true) {
            List<String> datosCuenta = cliente.login(vistaLogin.getTxtusuario().getText(), vistaLogin.getTxtpassword().getText());

            if (!(datosCuenta.isEmpty())) {

                vistaLogin.setVisible(false);
                vistacuenta.setVisible(true);
                vistacuenta.getLbID().setText(datosCuenta.get(0));
                vistacuenta.getLbusuario().setText(datosCuenta.get(1));
                vistacuenta.getTxtsaldo().setText(datosCuenta.get(2));
                vistacuenta.getTxtsaldo().setEnabled(false);
                vistacuenta.getLbID().setEnabled(false);
                vistaLogin.getLbmensaje().setText("");
            } else {

                vistaLogin.getLbmensaje().setText("Usuario no existe o las credenciales son incorrectas.");
                vistaLogin.getLbmensaje().setForeground(Color.red);
            }

        } else {
            vistaLogin.getLbmensaje().setText("Campos Vacios.");
            vistaLogin.getLbmensaje().setForeground(Color.red);

        }

    }

    public void actualizarSaldo() {

        if (validarCamposCuenta() == true) {
            double saldo = 0;

            if (vistacuenta.getjRadioButtonDeposito().isSelected()) {

                saldo = Double.parseDouble(vistacuenta.getTxtsaldo().getText()) + Double.parseDouble(vistacuenta.getTxtvalor().getText());
                cliente.actualizarSaldo(Integer.parseInt(vistacuenta.getLbID().getText()), saldo);
                vistacuenta.getLbmensaje().setText("Deposito Realizado con exìto.");
                vistacuenta.getLbmensaje().setForeground(Color.BLUE);
                iniciarSesion();
                vistacuenta.getTxtvalor().setText("");
            } else if (vistacuenta.getjRadioButtonRetiro().isSelected()) {

                saldo = Double.parseDouble(vistacuenta.getTxtsaldo().getText()) - Double.parseDouble(vistacuenta.getTxtvalor().getText());
                if (saldo >= 0) {

                    cliente.actualizarSaldo(Integer.parseInt(vistacuenta.getLbID().getText()), saldo);
                    vistacuenta.getLbmensaje().setText("Retiro Realizado con exìto.");
                    vistacuenta.getLbmensaje().setForeground(Color.BLUE);
                    iniciarSesion();
                    vistacuenta.getTxtvalor().setText("");
                } else {
                    vistacuenta.getLbmensaje().setText("Saldo Insuficiente.");
                    vistacuenta.getLbmensaje().setForeground(Color.red);
                    vistacuenta.getTxtvalor().setText("");
                }

            } else {
                vistacuenta.getTxtvalor().setText("");
            }

        } else {

            vistacuenta.getLbmensaje().setText("Revise la información Ingresada.");
            vistacuenta.getLbmensaje().setForeground(Color.red);
            vistacuenta.getTxtvalor().setText("");

        }

    }

    public void cerrarSesion() {
        vistaLogin.setVisible(true);
        vistacuenta.setVisible(false);

        limpiarDatosCuenta();
        limpiarDatosLogin();
        limpiarDatosRegistro();

    }

    public void atrasRegistro() {

        vistaregistro.setVisible(false);
        vistaLogin.setVisible(true);
        limpiarDatosCuenta();
        limpiarDatosLogin();
    }

    public boolean validarCamposLogin() {
        if (vistaLogin.getTxtusuario().getText().isEmpty()) {

            return false;
        }

        if (vistaLogin.getTxtpassword().getText().isEmpty()) {

            return false;
        }

        return true;

    }

    public boolean validarCamposRegistro() {

        if (vistaregistro.getTxtusuario().getText().isEmpty()) {
            return false;
        }
        if (vistaregistro.getTxtclave().getText().isEmpty()) {
            return false;
        }
        if (vistaregistro.getTxtclaveconfirmacion().getText().isEmpty()) {
            return false;
        }
        if (vistaregistro.getTxtsaldo().getText().isEmpty()) {

            return false;
        }

        return true;

    }

    public boolean validarCamposCuenta() {

//        if (!vistacuenta.getjRadioButtonDeposito().isSelected()) {
//            return false;
//        }
//        if (!vistacuenta.getjRadioButtonRetiro().isSelected()) {
//            return false;
//        }
        if (vistacuenta.getTxtvalor().getText().isEmpty()) {
            return false;
        }

        return true;
    }

    public void limpiarDatosRegistro() {

        vistaregistro.getTxtusuario().setText("");
        vistaregistro.getTxtclave().setText("");
        vistaregistro.getTxtclaveconfirmacion().setText("");
        vistaregistro.getTxtsaldo().setText("");
        vistaregistro.getLbmensaje().setText("");

    }

    public void limpiarDatosLogin() {

        vistaLogin.getTxtusuario().setText("");
        vistaLogin.getTxtpassword().setText("");
        vistaLogin.getLbmensaje().setText("");

    }

    public void limpiarDatosCuenta() {

        vistacuenta.getTxtsaldo().setText("");
        vistacuenta.getTxtvalor().setText("");
        vistacuenta.getLbID().setText("");
        vistacuenta.getLbmensaje().setText("");
        vistacuenta.getLbusuario().setText("");
        vistacuenta.getjRadioButtonDeposito().setSelected(false);
        vistacuenta.getjRadioButtonRetiro().setSelected(false);
    }
}
