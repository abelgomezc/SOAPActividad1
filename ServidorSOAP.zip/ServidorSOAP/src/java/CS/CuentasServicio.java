/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CS;

import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import modelo.ModeloCuenta;

/**
 *
 * @author Abel Gomez
 */
@WebService(serviceName = "CuentasServicio")
public class CuentasServicio {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    @WebMethod(operationName = "crearCuenta")
    public boolean crearCuenta(@WebParam(name = "usuario") String usuario,
            @WebParam(name = "password") String password,
            @WebParam(name = "passwordconfirmar") String passwordconfirmar,
            @WebParam(name = "saldoInicial") double saldoInicial) {

        if (password.equals(passwordconfirmar)) {
            ModeloCuenta modeloCuenta = new ModeloCuenta();
            modeloCuenta.setUsuario(usuario);
            modeloCuenta.setPassword(password);
            modeloCuenta.setSaldo(saldoInicial);
            return modeloCuenta.setCuenta();

        }
        return false;

    }

    @WebMethod(operationName = "login")
    public List<String> login(@WebParam(name = "usuario") String usuario,
            @WebParam(name = "password") String password) {

        ModeloCuenta modeloCuenta = new ModeloCuenta();

        modeloCuenta.setUsuario(usuario);
        modeloCuenta.setPassword(password);

        List<String> usarioencontrado = modeloCuenta.login(usuario, password);

        if (usarioencontrado == null) {
            return null;
        }

        return usarioencontrado;
    }

    @WebMethod(operationName = "actualizarSaldo")
    public boolean actualizarSaldoCuenta(@WebParam(name = "id") int id, @WebParam(name = "saldo") Double saldo) {

        ModeloCuenta modeloCuenta = new ModeloCuenta();

        if (modeloCuenta.updateCuenta(id, saldo)) {

            return true;

        }
        return false;

    }

}
