/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Abel Gomez
 */
public class ModeloCuenta extends Cuenta {

    ModelConexion mpgc = new ModelConexion();

    public ModeloCuenta() {
    }

    public ModeloCuenta(int id, String usuario, String password, Double saldo) {
        super(id, usuario, password, saldo);
    }

    public boolean setCuenta() {
        String sql = "INSERT INTO cuentas (usuario,contrasena,saldo) ";
        sql += "VALUES (?,?,?)";

        try {
            PreparedStatement ps = mpgc.conn.prepareStatement(sql);
            ps.setString(1, getUsuario());
            ps.setString(2, getPassword());
            ps.setDouble(3, getSaldo());

            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(ModeloCuenta.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

    public List<String> login(String usuario, String password) {
       // String usuarioResi = "";
         List<String> datosdecuenta = new ArrayList<String>();
      //  int id = 0;

        String sql = "select id,usuario,saldo from cuentas where usuario = '" + usuario + "' and contrasena = '" + password + "' LIMIT 1";
        ResultSet rs = mpgc.consulta(sql);

        try {

            if (rs.next()) {
              //  id = rs.getInt(1);
                // usuarioResi = rs.getString(2);

               // usuarioResi = String.valueOf(id) + "-" + rs.getString(2);
               datosdecuenta.add(String.valueOf(rs.getInt(1)));
               datosdecuenta.add(rs.getString(2));
               datosdecuenta.add(String.valueOf(rs.getDouble(3)));

            } else {
                datosdecuenta = null;
            }
        } catch (Exception e) {
            Logger.getLogger(ModelConexion.class.getName()).log(Level.SEVERE, null, e);
        }

        try {
            rs.close();

        } catch (SQLException ex) {
            Logger.getLogger(ModeloCuenta.class.getName()).log(Level.SEVERE, null, ex);
        }

        return datosdecuenta;

    }

    public boolean updateCuenta(int id, double saldo) {

        String sql = "UPDATE cuentas SET saldo = ?"
                + " WHERE id = " + id + ";";

        try {
            PreparedStatement ps = mpgc.conn.prepareStatement(sql);
            ps.setDouble(1, saldo);

            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(ModeloCuenta.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

}

//CREATE TABLE cuentas (
//    id SERIAL PRIMARY KEY,
//    usuario VARCHAR(50) NOT NULL,
//    contrasena VARCHAR(50) NOT NULL,
//    saldo numeric NOT NULL
//);
